import DS from 'ember-data';

export default DS.LSAdapter.extend({
  namespace: 'pilas-engine-bloques-ds2'
});
