import Ember from 'ember';

export default Ember.Service.extend({
    getVersion() {
        return "0.7.2";
    }
});
